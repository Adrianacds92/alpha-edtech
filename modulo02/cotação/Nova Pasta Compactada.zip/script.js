// $(document).ready(function(){
//     $("table, td, th, tr").css("border", "1px solid green");
//     $("table").css("margin", "auto");
//     $("th").css("width", "200px");

$(document).ready(function () {
    $("table, td, th, tr").css("border", "1px solid red");
    $("table").css("margin", "auto");
    $("th").css("width", "150px");
    $.ajax({ url: "https://economia.awesomeapi.com.br/json/all" })
        .done((data) => {
            Object.entries(data).forEach((moeda) => {
                $("#coins").append(`<option>${moeda[0]}</option>`);
            });
        });
    $("#date").on("change", function () {
        const data = $(this).val().replaceAll("-", "");
        const moeda = $("#coins").val();
        $.ajax({ url: `https://economia.awesomeapi.com.br/${moeda}/?start_date=${data}&end_date=${data}` })
            .done((data) => {
                const dados = Object.entries(data)[0][1]
                $("#name").html(`<p> Moeda:</p> ${dados.name}`);
                $("#bid").html(`<p> Ultima cotação:</p> ${dados.bid}`);
                $("#data").html(`<p> Data:</p>${dados.create_date}`);
                $("#low").html(`<p> Valor Mínimo:</p> ${dados.low}`);
                $("#high").html(`<p> Valor Máximo: </p>${dados.high}`);
                $("#ask").html(`<p> Valor Fechamento:</p>${dados.ask}`);
                // data = data[0]              
                // $("#name").append(`<p> ${data.name}</p>`);
                // $("#bid").append(`<p> ${data.bid}</p>`);
                // $("#data").append(`<p>${data.create_date}</p>`);
                // $("#low").append(`<p> ${data.low}</p>`);
                // $("#high").append(`<p> ${data.high}</p>`);
                // $("#ask").append(`<p>${data.ask}</p>`);
                // // $("#return").html("");
                
            })
        $("#button").on("click", function () {
            $("#return").html("");
        })
    })
})
